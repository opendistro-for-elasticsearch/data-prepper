import _ from 'lodash';
const fields = [
  'spanId',
  'traceId',
  'kind',
  'name',
  'durationInNanos',
  'attributes_component',
  'parentSpanId',
  'events.attributes.value',
  'resource.attributes.service',
  'attributes_http',
  'attributes_host',
  'attributes_db',
  'resource.attributes.telemetry.sdk',
  'resource.attributes.service.instance',
  'attributes.net.peer',
  'attributes.dispatcher',
  'attributes_servlet',
  'attributes.db',
  'resource.attributes.host',
  'attributes',
  'attributes_net.peer',
  'events.attributes',
  'attributes.http',
  'attributes.host',
  'events',
  'attributes.servlet',
  'status',
];

const mapping = {
  attributes: {
    host: {
      port: 'long',
    },
    http: {
      response_content_length: 'long',
      status_code: 'long',
    },
    net: {
      port: 'long',
    },
  },
  attributes_host: {
    port: 'long',
  },
  attributes_http: {
    response_content_length: 'long',
    status_code: 'long',
  },
  attributes_net: {
    port: 'long',
  },
  durationInNanos: 'long',
  endTime: 'date_nanos',
  startTime: 'date_nanos',
};

const operatorMapping = {
  long: [
    {
      label: 'is between',
      key: 'isBetweenNumber',
      invert: false,
    },
    {
      label: 'is not between',
      key: 'isBetweenNumber',
      invert: true,
    },
  ],
  date_nanos: [
    {
      label: 'is between',
      key: 'isBetweenDate',
      invert: false,
    },
    {
      label: 'is not between',
      key: 'isBetweenDate',
      invert: true,
    },
  ],
  default_first: [
    {
      label: 'is',
      key: 'is',
      invert: false,
    },
    {
      label: 'is not between',
      key: 'isBetweenDate',
      invert: true,
    },
    
  ]
};

export const getType = (field: string): string => {
  const type = _.get(mapping, field, 'keyword');
  return typeof type === 'string' ? type : null;
};

export const getOperators = (type: string) => {
  const operators = [
    {
      label: 'is between',
      key: 'isBetweenDate',
      invert: false,
    },
    {
      label: 'is not between',
      key: 'isBetweenDate',
      invert: true,
    },
    {
      label: 'is between',
      key: 'isBetweenDate',
      invert: false,
    },
    {
      label: 'is not between',
      key: 'isBetweenDate',
      invert: true,
    },
    {
      label: 'is between',
      key: 'isBetweenDate',
      invert: false,
    },
    {
      label: 'is not between',
      key: 'isBetweenDate',
      invert: true,
    },
  ];
};
